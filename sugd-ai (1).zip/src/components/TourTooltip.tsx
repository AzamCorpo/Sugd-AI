import React from 'react';
import { TooltipRenderProps } from 'react-joyride';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, ChevronLeft, X, Check, Bot } from 'lucide-react';

export const TourTooltip = ({
  continuous,
  index,
  step,
  backProps,
  closeProps,
  primaryProps,
  tooltipProps,
  isLastStep,
}: TooltipRenderProps) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: 10, scale: 0.95 }}
      className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-xl border border-slate-200/50 dark:border-white/10 rounded-3xl p-6 w-80 shadow-2xl relative overflow-hidden"
      {...tooltipProps}
    >
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 to-purple-500" />
      
      <button 
        {...closeProps}
        className="absolute top-4 right-4 p-1.5 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-full transition-colors text-slate-400 hover:text-slate-600 dark:hover:text-slate-300"
      >
        <X size={16} />
      </button>

      <div className="flex items-start gap-4 mb-4">
        <div className="relative shrink-0">
          <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <Bot size={24} className="text-white" />
          </div>
          <div className="absolute -bottom-1 -right-1 bg-emerald-500 w-3.5 h-3.5 rounded-full border-2 border-white dark:border-slate-900" />
        </div>
        <div>
          <h4 className="text-xs font-bold text-indigo-500 uppercase tracking-wider mb-0.5">Wegvip</h4>
          {step.title && (
            <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-tight">
              {step.title}
            </h3>
          )}
        </div>
      </div>
      
      <div className="text-slate-600 dark:text-slate-400 text-sm leading-relaxed mb-6 font-medium bg-slate-50 dark:bg-black/20 p-3 rounded-2xl">
        {step.content}
      </div>

      <div className="flex items-center justify-between">
        <div className="flex gap-1.5">
          {Array.from({ length: 5 }).map((_, i) => (
            <div 
              key={i} 
              className={`h-1.5 rounded-full transition-all duration-300 ${i === index ? 'w-4 bg-indigo-500' : 'w-1.5 bg-slate-200 dark:bg-slate-700'}`}
            />
          ))}
        </div>
        
        <div className="flex gap-2">
          {index > 0 && (
            <button
              {...backProps}
              className="p-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-colors text-slate-600 dark:text-slate-400 disabled:opacity-50"
            >
              <ChevronLeft size={16} />
            </button>
          )}
          <button
            {...primaryProps}
            className="flex items-center gap-2 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs uppercase tracking-wider transition-colors shadow-lg shadow-indigo-500/20"
          >
            {isLastStep ? (
              <>Done <Check size={14} /></>
            ) : (
              <>Next <ChevronRight size={14} /></>
            )}
          </button>
        </div>
      </div>
    </motion.div>
  );
};
