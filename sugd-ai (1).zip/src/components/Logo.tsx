import React from 'react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export const Logo = ({ className = "" }: { className?: string }) => {
  return (
    <div className={cn("flex items-center gap-3", className)}>
      <div className="relative w-10 h-10 flex-shrink-0">
        <motion.svg
          viewBox="0 0 100 100"
          className="w-full h-full text-blue-600 dark:text-blue-500 drop-shadow-md"
          initial={{ rotate: -10, scale: 0.9, opacity: 0 }}
          animate={{ rotate: 0, scale: 1, opacity: 1 }}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          <g fill="none" stroke="currentColor" strokeWidth="12" strokeLinecap="butt" strokeLinejoin="miter">
            {/* Upper Hook */}
            <motion.path
              d="M 80 32 L 80 25 C 80 12, 65 8, 50 2 C 35 8, 20 12, 20 25 L 20 52 C 20 64, 32 72, 45 66"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 1 }}
              transition={{ duration: 1.2, ease: "easeOut" }}
            />
            {/* Lower Hook */}
            <motion.path
              d="M 20 68 L 20 75 C 20 88, 35 92, 50 98 C 65 92, 80 88, 80 75 L 80 48 C 80 36, 68 28, 55 34"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 1 }}
              transition={{ duration: 1.2, ease: "easeOut", delay: 0.1 }}
            />
          </g>
          
          {/* Center Star */}
          <motion.path
            d="M 50 36 Q 50 50, 64 50 Q 50 50, 50 64 Q 50 50, 36 50 Q 50 50, 50 36 Z"
            fill="currentColor"
            initial={{ scale: 0, rotate: -45 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ duration: 0.8, delay: 0.6, type: "spring", stiffness: 200 }}
          />
        </motion.svg>
        
        {/* Glow effect */}
        <div className="absolute inset-0 bg-blue-600/20 dark:bg-blue-400/30 blur-xl rounded-full -z-10" />
      </div>
      <div className="flex flex-col">
        <span className="text-[9px] uppercase tracking-[0.2em] text-blue-500 font-bold mt-0.5" style={{letterSpacing: "0.2em"}}>Azam Corp</span>
      </div>
    </div>
  );
};
