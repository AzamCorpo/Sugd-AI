import React, { useState, useEffect, useRef } from 'react';
import { collection, query, orderBy, limit, addDoc, serverTimestamp, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Send, User, X, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { toast } from 'sonner';
import { useAuth } from '../lib/AuthContext';

export const GlobalChat = ({ onClose, onSelectUser }: { onClose: () => void, onSelectUser: (userId: string) => void }) => {
  const { user, profile, localGuest } = useAuth();
  const [messages, setMessages] = useState<any[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(true);
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Only fetch if db is available
    if (!db) {
      setLoading(false);
      return;
    }
    const q = query(
      collection(db, 'global_messages'),
      orderBy('createdAt', 'desc'),
      limit(50)
    );
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })).reverse();
      setMessages(msgs);
      setLoading(false);
      setTimeout(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    }, (error) => {
      console.error(error);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleSend = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    
    if (localGuest && !user) {
      toast.error('Global chat is read-only for local guests without Firebase auth');
      return;
    }

    try {
      await addDoc(collection(db, 'global_messages'), {
        text: input,
        userId: user?.uid || 'guest',
        username: profile?.username || profile?.fullName || 'User',
        photoUrl: profile?.photoUrl || null,
        createdAt: serverTimestamp()
      });
      setInput('');
    } catch (e) {
      console.error(e);
      toast.error('Failed to send message');
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="fixed inset-0 sm:inset-auto sm:top-1/2 sm:left-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2 sm:w-[500px] sm:h-[700px] bg-white/40 dark:bg-black/40 backdrop-blur-3xl sm:rounded-[2rem] sm:shadow-2xl sm:border border-slate-200/50 dark:border-white/10 z-50 flex flex-col overflow-hidden"
    >
      <div className="flex items-center justify-between p-4 border-b border-slate-200/50 dark:border-white/10 bg-white/20 dark:bg-black/20 backdrop-blur-md">
        <div>
          <h2 className="text-lg font-bold text-slate-800 dark:text-slate-200 flex items-center gap-2">
            <User size={18} className="text-indigo-500" /> 
            Global Chat / Глобальный чат
          </h2>
          <p className="text-xs text-slate-500">Live community / Живое общество</p>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-slate-200/50 dark:hover:bg-white/10 rounded-xl transition-colors">
          <X className="text-slate-500" size={20} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-transparent">
        {loading ? (
          <div className="flex justify-center items-center h-full">
            <Loader2 className="animate-spin text-indigo-500" />
          </div>
        ) : messages.length === 0 ? (
          <div className="text-center text-slate-500 dark:text-slate-400 mt-10 text-sm">No messages yet. Say hi!</div>
        ) : (
          messages.map(msg => {
            const isMe = msg.userId === user?.uid || (localGuest && msg.userId === 'guest');
            return (
              <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                <div className="flex items-center gap-2 mb-1">
                  {!isMe && (
                    <button 
                      onClick={() => onSelectUser(msg.userId)}
                      className="text-[10px] font-bold text-slate-500 dark:text-slate-400 hover:text-indigo-500 transition-colors uppercase tracking-wider flex items-center gap-1"
                    >
                      {msg.photoUrl ? (
                        <img src={msg.photoUrl} alt="" className="w-4 h-4 rounded-full object-cover" />
                      ) : (
                        <User size={10} />
                      )}
                      {msg.username}
                    </button>
                  )}
                </div>
                <div className={`px-4 py-2.5 rounded-2xl max-w-[85%] text-sm ${isMe ? 'bg-indigo-600/90 backdrop-blur-md text-white rounded-br-sm' : 'bg-white/60 dark:bg-black/40 backdrop-blur-md border border-slate-200/50 dark:border-white/5 text-slate-900 dark:text-slate-200 rounded-bl-sm shadow-sm'}`}>
                  {msg.text}
                </div>
              </div>
            );
          })
        )}
        <div ref={endRef} />
      </div>

      <form onSubmit={handleSend} className="p-4 bg-white/20 dark:bg-black/20 backdrop-blur-md border-t border-slate-200/50 dark:border-white/10">
        <div className="flex items-center gap-2 bg-white/40 dark:bg-black/40 p-1.5 rounded-2xl border border-slate-200/50 dark:border-white/5">
          <input
            type="text"
            value={input}
            onChange={e => setInput(e.target.value)}
            placeholder="Type a message... / Напишите сообщение..."
            className="flex-1 bg-transparent border-none focus:ring-0 text-sm px-3 text-slate-800 dark:text-slate-200"
          />
          <button 
            type="submit"
            disabled={!input.trim()}
            className="p-2 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-colors"
          >
            <Send size={18} />
          </button>
        </div>
      </form>
    </motion.div>
  );
};
