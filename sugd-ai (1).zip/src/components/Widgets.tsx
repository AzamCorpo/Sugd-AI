import React from 'react';
import { Sunrise, Sun, Sunset, Moon, Clock, Newspaper, ExternalLink, TrendingUp, Globe, Briefcase, Heart } from 'lucide-react';

export interface PrayerTimings {
  Fajr: string;
  Sunrise: string;
  Dhuhr: string;
  Asr: string;
  Maghrib: string;
  Isha: string;
}

export const PrayerCard = ({ data }: { data: { city: string, timings: PrayerTimings } }) => {
  const prayerIcons: Record<string, any> = {
    'Fajr': <Sunrise size={14} className="text-amber-200" />,
    'Sunrise': <Sun size={14} className="text-amber-300" />,
    'Dhuhr': <Sun size={14} className="text-yellow-400" />,
    'Asr': <Sun size={14} className="text-orange-400" />,
    'Maghrib': <Sunset size={14} className="text-rose-300" />,
    'Isha': <Moon size={14} className="text-indigo-200" />
  };

  return (
    <div className="my-8 p-0 bg-[#0a2e2a] rounded-[2.5rem] text-white shadow-[0_20px_50px_rgba(0,0,0,0.3)] relative overflow-hidden group/card max-w-sm border border-emerald-500/20">
      <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl -mr-16 -mt-16" />
      <div className="absolute bottom-0 left-0 w-32 h-32 bg-teal-500/10 rounded-full blur-3xl -ml-16 -mb-16" />
      
      <div className="p-6 pb-4 border-b border-white/5 relative z-10 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-6 h-6 bg-emerald-600 rounded-lg flex items-center justify-center">
              <span className="text-[10px] font-bold">S</span>
            </div>
            <span className="text-[10px] font-black uppercase tracking-[0.2em] text-emerald-400">Sugd AI</span>
          </div>
          <h3 className="text-2xl font-black tracking-tight text-white/90">{data.city}</h3>
        </div>
        <div className="text-right">
          <div className="text-[9px] font-bold uppercase tracking-widest text-emerald-500/60 mb-1">Source</div>
          <div className="px-3 py-1 bg-white/5 rounded-full border border-white/10 text-[10px] font-bold tracking-tighter uppercase">Aladhan</div>
        </div>
      </div>

      <div className="p-3 grid grid-cols-2 gap-2 relative z-10">
        {Object.entries(data.timings).filter(([k]) => ['Fajr', 'Sunrise', 'Dhuhr', 'Asr', 'Maghrib', 'Isha'].includes(k)).map(([name, time]) => (
          <div key={name} className="bg-white/[0.03] hover:bg-white/[0.07] border border-white/5 p-4 rounded-3xl transition-all duration-300 group/tile">
            <div className="flex items-center justify-between mb-2">
              <div className="text-[10px] font-bold uppercase tracking-widest text-white/40">{name}</div>
              <div className="opacity-50 group-hover/tile:opacity-100 transition-opacity">
                {prayerIcons[name] || <Clock size={14} />}
              </div>
            </div>
            <div className="text-xl font-black tracking-tight group-hover/tile:scale-105 transition-transform origin-left">{time}</div>
          </div>
        ))}
      </div>

      <div className="p-4 pt-0 text-center relative z-10">
        <div className="text-[9px] font-medium text-emerald-500/40 italic">
          Times are based on local coordination. Verify with your local mosque.
        </div>
      </div>
    </div>
  );
};

export interface NewsItem {
  title: string;
  source: string;
  url: string;
  summary: string;
  type: 'politics' | 'economy' | 'culture' | 'sport';
}

export const NewsCard = ({ data }: { data: { items: NewsItem[] } }) => {
  const typeIcons = {
    politics: <Globe size={18} className="text-blue-500" />,
    economy: <TrendingUp size={18} className="text-emerald-500" />,
    culture: <Heart size={18} className="text-rose-500" />,
    sport: <Briefcase size={18} className="text-amber-500" />,
    technology: <Newspaper size={18} className="text-sky-500" />,
    science: <Newspaper size={18} className="text-purple-500" />,
    health: <Heart size={18} className="text-red-500" />
  } as any;

  return (
    <div className="my-10 w-full max-w-3xl bg-white dark:bg-[#0d1117] rounded-[3rem] border border-black/5 dark:border-white/5 shadow-2xl overflow-hidden relative group/news transition-all duration-500 hover:shadow-indigo-500/10 hover:border-indigo-500/20">
      <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-sky-500 to-emerald-500 z-20" />
      <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/5 rounded-full blur-[80px] -mr-40 -mt-40 pointer-events-none" />
      
      <div className="p-8 md:p-10 border-b border-black/5 dark:border-white/5 relative z-10 flex items-center justify-between bg-slate-50/50 dark:bg-white/[0.02]">
        <div className="flex items-center gap-5">
          <div className="w-14 h-14 bg-gradient-to-br from-indigo-600 to-sky-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-indigo-500/30 transform group-hover/news:rotate-3 transition-transform duration-700">
            <Newspaper className="text-white" size={28} />
          </div>
          <div>
            <h3 className="text-2xl md:text-3xl font-black tracking-tight text-slate-900 dark:text-white uppercase leading-none italic">Sogdian Post</h3>
            <div className="flex items-center gap-2 mt-2">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <p className="text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em]">Sugd AI Global Intel • World Report</p>
            </div>
          </div>
        </div>
        <div className="hidden sm:block text-right">
          <div className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-1 italic">Published</div>
          <div className="text-sm font-black text-slate-900 dark:text-white uppercase tracking-tighter">
            {new Date().toLocaleDateString('en-US', { day: 'numeric', month: 'short', year: 'numeric' })}
          </div>
        </div>
      </div>

      <div className="divide-y divide-black/5 dark:divide-white/5 relative z-10">
        {data.items.slice(0, 3).map((item, idx) => (
          <div key={idx} className="p-8 md:p-10 hover:bg-black/[0.01] dark:hover:bg-white/[0.01] transition-all duration-500 group/item relative">
            <div className="absolute left-0 top-0 w-1 h-full bg-indigo-500 scale-y-0 group-hover/item:scale-y-100 transition-transform duration-500" />
            <div className="flex flex-col gap-5">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2 px-3 py-1 bg-indigo-500/5 dark:bg-indigo-500/10 rounded-full border border-indigo-500/10">
                  {typeIcons[item.type] || <Globe size={14} className="text-indigo-400" />}
                  <span className="text-[10px] font-black uppercase tracking-widest text-indigo-500">{item.type || 'news'}</span>
                </div>
                <span className="text-[9px] font-black text-slate-300 dark:text-slate-700 uppercase tracking-widest">/</span>
                <span className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">{item.source}</span>
              </div>
              
              <div className="space-y-3">
                <h4 className="text-xl md:text-2xl font-black text-slate-900 dark:text-white group-hover/item:text-indigo-600 dark:group-hover/item:text-indigo-400 transition-colors leading-tight tracking-tight">
                  {item.title}
                </h4>
                <p className="text-[15px] text-slate-600 dark:text-slate-400 leading-relaxed line-clamp-3">
                  {item.summary}
                </p>
              </div>

              <div className="flex items-center justify-between mt-2 pt-5 border-t border-black/[0.03] dark:border-white/[0.03]">
                <a 
                  href={item.url} 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="inline-flex items-center gap-2 text-[11px] font-black text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 uppercase tracking-widest transition-colors group/link"
                >
                  Read Intelligence report <ExternalLink size={14} className="group-hover/link:translate-x-1 group-hover/link:-translate-y-1 transition-transform" />
                </a>
                <div className="flex -space-x-2">
                  {[1,2,3].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 border-2 border-white dark:border-[#0d1117] flex items-center justify-center">
                       <span className="text-[8px] font-bold text-slate-400">#</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="p-8 bg-slate-50/50 dark:bg-white/[0.01] border-t border-black/5 dark:border-white/5 text-center flex items-center justify-between">
        <div className="flex items-center gap-2">
           <div className="w-2 h-2 rounded-full bg-indigo-500" />
           <span className="text-[8px] font-black text-slate-400 uppercase tracking-[0.3em]">Encrypted Data Stream</span>
        </div>
        <p className="text-[9px] font-black text-slate-400 tracking-widest uppercase">
          AI ARCHITECTURE BY AZAM CORP
        </p>
      </div>
    </div>
  );
};
