import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { collection, query, getDocs, doc, getDoc, updateDoc, deleteDoc, setDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../lib/AuthContext';
import { toast } from 'sonner';
import { X, User, MessageSquare, Check, X as XIcon, Loader2, Globe, ChevronRight } from 'lucide-react';

export const FriendsMenu = ({ 
  onClose,
  onOpenMessage,
  onOpenProfile
}: { 
  onClose: () => void,
  onOpenMessage: (chatId: string, profile: any) => void,
  onOpenProfile: (userId: string) => void
}) => {
  const { user: currentUser } = useAuth();
  const [friends, setFriends] = useState<any[]>([]);
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchUsername, setSearchUsername] = useState('');
  const [searching, setSearching] = useState(false);
  
  const handleSearchUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchUsername.trim()) return;
    
    setSearching(true);
    try {
      const q = query(collection(db, 'users'));
      const querySnapshot = await getDocs(q);
      const formattedSearch = searchUsername.trim().toLowerCase();
      let foundUserId = null;
      let foundUsername = null;
      
      // Look through all users for a matching username
      // Since usernames can have different cases in display but are stored lowercased in 'usernames' collection
      const usernameDoc = await getDoc(doc(db, 'usernames', formattedSearch));
      if (usernameDoc.exists()) {
         foundUserId = usernameDoc.data().userId;
      }
      
      if (foundUserId) {
        if (foundUserId === currentUser?.uid) {
           toast.error("You cannot search yourself");
        } else {
           onClose();
           onOpenProfile(foundUserId);
        }
      } else {
        toast.error("User not found / Пользователь не найден");
      }
    } catch (e) {
      console.error(e);
      toast.error("Error searching user");
    }
    setSearching(false);
  };

  useEffect(() => {
    if (!currentUser) return;

    const loadFriendsData = async () => {
      try {
        // Load Friends
        const fSnap = await getDocs(collection(db, 'users', currentUser.uid, 'friends'));
        const fData: any[] = [];
        for (const f of fSnap.docs) {
          const uDoc = await getDoc(doc(db, 'users', f.id));
          if (uDoc.exists()) {
            fData.push({ id: f.id, ...uDoc.data() });
          }
        }
        setFriends(fData);

        // Load Friend Requests
        const rSnap = await getDocs(collection(db, 'users', currentUser.uid, 'friend_requests'));
        const rData: any[] = [];
        for (const req of rSnap.docs) {
          const uDoc = await getDoc(doc(db, 'users', req.id));
          if (uDoc.exists()) {
            rData.push({ id: req.id, ...uDoc.data() });
          }
        }
        setRequests(rData);

      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    loadFriendsData();
  }, [currentUser]);

  const handleAcceptRequest = async (requesterId: string) => {
    if (!currentUser) return;
    try {
      // Add friend to my friends list
      await setDoc(doc(db, 'users', currentUser.uid, 'friends', requesterId), { active: true });
      // Add me to requester's friends list
      await setDoc(doc(db, 'users', requesterId, 'friends', currentUser.uid), { active: true });
      // Remove request
      await deleteDoc(doc(db, 'users', currentUser.uid, 'friend_requests', requesterId));

      setRequests(prev => prev.filter(req => req.id !== requesterId));
      
      // refresh friends
      const uDoc = await getDoc(doc(db, 'users', requesterId));
      if (uDoc.exists()) {
        setFriends(prev => [...prev, { id: requesterId, ...uDoc.data() }]);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleDeclineRequest = async (requesterId: string) => {
    if (!currentUser) return;
    try {
      await deleteDoc(doc(db, 'users', currentUser.uid, 'friend_requests', requesterId));
      setRequests(prev => prev.filter(req => req.id !== requesterId));
    } catch (e) {
      console.error(e);
    }
  };

  const openVipMessage = async (fId: string, fProfile: any) => {
    if (!currentUser) return;
    const sortedIds = [currentUser.uid, fId].sort();
    const chatId = `${sortedIds[0]}_${sortedIds[1]}`;
      
    const chatRef = doc(db, 'direct_messages', chatId);
    const chatDoc = await getDoc(chatRef);
    if (!chatDoc.exists()) {
      await setDoc(chatRef, {
        participants: [currentUser.uid, fId],
      });
    }
    onClose();
    onOpenMessage(chatId, fProfile);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[90] flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="w-full max-w-md border border-black/10 dark:border-white/10 rounded-[2.5rem] shadow-2xl overflow-hidden glass-liquid"
      >
        <div className="p-6 border-b border-black/5 dark:border-white/5 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold dark:text-white flex items-center gap-2">
              <MessageSquare size={20} className="text-indigo-500" />
              Messenger / Паёмрасон
            </h2>
            <button onClick={onClose} className="p-2 hover:bg-black/5 dark:hover:bg-white/5 rounded-xl transition-colors">
              <X size={20} className="text-slate-500" />
            </button>
          </div>
          
          <button 
            onClick={() => {
               onClose();
               const clickEvent = new MouseEvent('click', { bubbles: true });
               document.getElementById('open-global-chat-btn')?.dispatchEvent(clickEvent);
            }}
            className="w-full flex items-center justify-between p-4 bg-gradient-to-r from-indigo-500/10 to-purple-500/10 hover:from-indigo-500/20 hover:to-purple-500/20 border border-indigo-500/20 rounded-2xl transition-all group"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-500 flex items-center justify-center group-hover:scale-110 transition-transform">
                <Globe size={18} />
              </div>
              <div className="text-left">
                <h3 className="text-sm font-bold text-slate-800 dark:text-white">Global World Chat / Глобальный чат</h3>
                <p className="text-[10px] text-slate-500 uppercase tracking-widest">Join the community / Присоединяйтесь</p>
              </div>
            </div>
            <ChevronRight size={18} className="text-slate-400 group-hover:text-indigo-500 transition-colors" />
          </button>
          
          <form onSubmit={handleSearchUser} className="relative">
             <input
               type="text"
               value={searchUsername}
               onChange={(e) => setSearchUsername(e.target.value.replace('@',''))}
               placeholder="Search by username / Ҷустуҷӯи корбар..."
               className="w-full bg-white/40 dark:bg-black/40 border border-black/10 dark:border-white/10 rounded-2xl px-4 py-3 pl-10 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 transition-all text-slate-900 dark:text-slate-100"
             />
             <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">@</div>
             <button type="submit" disabled={searching || !searchUsername.trim()} className="absolute right-2 top-1/2 -translate-y-1/2 px-3 py-1.5 bg-indigo-500 text-white text-[10px] uppercase font-bold tracking-widest rounded-xl hover:bg-indigo-600 disabled:opacity-50">
               {searching ? '...' : 'Find / Ёфтан'}
             </button>
          </form>
        </div>

        <div className="p-6 space-y-8 max-h-[60vh] overflow-y-auto">
          {loading ? (
             <div className="flex justify-center py-4"><Loader2 className="animate-spin text-indigo-500" /></div>
          ) : (
            <>
              {requests.length > 0 && (
                <div className="space-y-4">
                  <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">Friend Requests / Дархостҳо</h3>
                  <div className="space-y-3">
                    {requests.map(req => (
                      <div key={req.id} className="flex items-center justify-between bg-black/5 dark:bg-white/5 p-3 rounded-2xl">
                        <div className="flex items-center gap-3 cursor-pointer" onClick={() => { onClose(); onOpenProfile(req.id); }}>
                          {req.photoUrl ? (
                            <img src={req.photoUrl} alt="" className="w-10 h-10 rounded-xl object-cover" />
                          ) : (
                            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-500 flex items-center justify-center">
                              <User size={16} />
                            </div>
                          )}
                          <div>
                            <p className="text-sm font-bold dark:text-white">{req.fullName || req.username}</p>
                            <p className="text-[10px] text-slate-500 uppercase">@{req.username}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <button onClick={() => handleAcceptRequest(req.id)} className="p-2 bg-emerald-500/20 text-emerald-600 hover:bg-emerald-500/30 rounded-xl transition-colors">
                            <Check size={16} />
                          </button>
                          <button onClick={() => handleDeclineRequest(req.id)} className="p-2 bg-red-500/20 text-red-600 hover:bg-red-500/30 rounded-xl transition-colors">
                            <XIcon size={16} />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="space-y-4">
                <h3 className="text-xs font-bold text-slate-500 uppercase tracking-widest">My Friends / Дӯстони ман</h3>
                {friends.length === 0 ? (
                  <p className="text-sm text-slate-500 text-center py-4">No friends yet. / Ҳанӯз дӯстон нестанд.</p>
                ) : (
                  <div className="space-y-3">
                    {friends.map(friend => (
                      <div key={friend.id} className="flex flex-col sm:flex-row sm:items-center justify-between bg-black/5 dark:bg-white/5 p-3 rounded-2xl gap-3">
                        <div className="flex items-center gap-3 cursor-pointer" onClick={() => { onClose(); onOpenProfile(friend.id); }}>
                          {friend.photoUrl ? (
                            <img src={friend.photoUrl} alt="" className="w-10 h-10 rounded-xl object-cover" />
                          ) : (
                            <div className="w-10 h-10 rounded-xl bg-indigo-500/20 text-indigo-500 flex items-center justify-center">
                              <User size={16} />
                            </div>
                          )}
                          <div>
                            <p className="text-sm font-bold dark:text-white">{friend.fullName || friend.username}</p>
                            <p className="text-[10px] text-slate-500 uppercase">@{friend.username}</p>
                          </div>
                        </div>
                        <button 
                          onClick={() => openVipMessage(friend.id, friend)}
                          className="px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-indigo-700 transition"
                        >
                          <MessageSquare size={14} /> Message
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </motion.div>
    </div>
  );
};
